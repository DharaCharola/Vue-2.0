<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Task;
use Validator;
use Auth;

class TodoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('todo');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ],[
            'name.required' => 'Please add task name'
        ]);

        if($validator->fails())
        {
            return response()->json($validator->messages(), 422);
        }

        $task = new Task;
        $task->name = $request->get('name');
        $task->user_id = Auth::id();
        $task->status = 0;
        $task->save();

        return response()->json([
            'message' => 'Task Added Successfully',
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $task = Task::findOrFail($id);
        return response()->json(['task' => $task]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ],[
            'name.required' => 'Please add task name'
        ]);

        if($validator->fails())
        {
            return response()->json($validator->messages(), 422);
        }

        $task = Task::find($id);
        $task->name = $request->get('name');
        $task->save();

        return response()->json(['message' => 'Task updated successfully']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Task::find($id)->delete();
        return response()->json(['message' => 'Task deleted successfully']);
    }

    public function getList()
    {
        $tasks = Task::where('user_id', Auth::id())
                    ->get();
        return response()->json(['tasks'=>$tasks]);
       
    }

    public function changeStatus(Request $request) 
    {
        $task = Task::find($request->get('id'));
        $task->status = $request->get('status');
        $task->save();
        return response()->json(['success' => true]);
    }
}
