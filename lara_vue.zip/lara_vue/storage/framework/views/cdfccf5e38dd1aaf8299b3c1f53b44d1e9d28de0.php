<?php $__env->startSection('content'); ?>
<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" id="todo-container">
                <div class="card-header">Todos</div>

                <div class="card-body">
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" v-model="task.id" />
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label text-md-right">Task: </label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" v-model="task.name"/>
                            </div>

                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary" @click.prevent="setTask()" v-text="buttonText">
                                </button>
                            </div>
                        </div>
                    </form>
                    <div class="panel-body">
                        <table class="table table-striped task-table">

                            <!-- Table Headings -->
                            <thead>
                                <th colspan="2" class="text-center">Your Tasks</th>
                            </thead>

                            <!-- Table Body -->
                            <tbody>
                                <tr v-for="task in taskList">
                                    <!-- Task Name -->
                                    <td class="table-text text-left v-center">
                                        <input type="checkbox" class="m-10 checkbox v-center" v-model="task.status" @change="changeStatus(task.id, event)">
                                        <label v-text="task.name"  v-bind:class="{'completed' : task.status}"></label>
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-primary" @click="editTask(task.id)">Edit</button>
                                        <button class="btn btn-danger" @click="deleteTask(task.id)">Delete</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/todo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>