// To make vue panel open in devtool
Vue.config.devtools = true;
var todoBoard = new Vue({

   // DOM element on which vuejs wil work
    el: '#todo-container', 
    data() {
        return {
            task :{
                name : null,
                status : null,
                id : null
            },
            taskList : {},
            buttonText: '',

            // Set toastr options
            toastrOption: {
                positionClass: "toast-top-center",
                timeOut : 2000
            }
        }
    },
    methods:{

        setTask(){
            if (this.task.id) {
                this.updateTask();
            } else {
                this.addTask();
            }
        },

        // Add Task to Database
        addTask(){
            axios.post('/todos', {
                name : this.task.name})
            .then(response => {
                todoBoard.task.name = null;
                this.getTasks();
                toastr.success(response.data.message, '', todoBoard.toastrOption);
            })
            .catch((error) => {
                toastr.error(error.response.data.name, '', todoBoard.toastrOption);
            });
        },

        // Fetch Tasks from Database
        getTasks(){
            axios.get('/list')
            .then(response => {
                this.taskList = response.data.tasks;
                this.buttonText = 'Add Task';
            });
        },

        // Edit Particular Task
        editTask(tid){
            axios.get('/todos/'+tid+'/edit')
            .then(response => {
                this.task  = response.data.task;
                this.buttonText = 'Update Task';
            });
        },

        // Upadte task in Database
        updateTask(){
            axios.put('/todos/'+ this.task.id, {
                name : this.task.name})
            .then(response => {
                toastr.success(response.data.message, '',  todoBoard.toastrOption);
                this.buttonText = 'Add Task';
                this.task.name = '';
                this.getTasks();
            }).catch((error) => {
                toastr.error(error.response.data.name, '', todoBoard.toastrOption);
            })
        },

        // Delete task form Database
        deleteTask(tid){
            if (confirm('Are you sure to delete this task?')) {
                axios.delete('/todos/'+ tid)
                .then(response => {
                    toastr.success(response.data.message, '',  todoBoard.toastrOption);
                    this.getTasks();
                });
            }
        },

        // Change completion status of task
        changeStatus(tid, checkid){
            var currentTask = checkid.target;
            axios.post('/changeStatus',{
                id: tid,
                status : currentTask.checked
            })
            .then(response => {
                if (response.data.success && currentTask.checked) {
                    toastr.success('Good! you have done your task', '',  todoBoard.toastrOption);
                } else {
                    toastr.info('Try to complete your task', '',  todoBoard.toastrOption);
                }
                this.getTasks();
            });
        }
    },
    mounted() {
        this.getTasks();
    }
});

